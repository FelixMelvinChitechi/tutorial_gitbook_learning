gitbook install
gitbook build
gitbook pdf ./
mv book.pdf _book/